﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace XnaRace
{

    class Nos
    {
        public Vector2 Position;
        public bool Visible = true;
        public bool isEated = false;
        public Nos()
        {

        }
    }
}